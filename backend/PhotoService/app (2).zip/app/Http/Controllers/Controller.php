<?php
namespace App\Http\Controllers;


class Controller
{
    // можно оставить пустым, если нет общей логики
}
