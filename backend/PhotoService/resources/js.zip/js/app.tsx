import React,{useState} from 'react';

const App:React.FC = () => {
    const [file,setFile] = useState<File| null>(null);
    const [userId,setUserId] = useState<number>(0);
    const [result,setResult] = useState<string>('');
    
    const handleUpload = async () => {
    if (!file) return;

    const formData = new FormData();
    formData.append('userId', userId.toString());
    formData.append('file', file);

    const token = (document.querySelector('meta[name="csrf-token"]') as HTMLMetaElement)?.content;
    if (!token) {
        setResult('CSRF token not found');
        return;
    }

    const response = await fetch('/photos', {
        method: 'POST',
        headers: { 'X-CSRF-TOKEN': token },
        body: formData
    });

    const data = await response.json();
    setResult(JSON.stringify(data));
};


    return(
        <div style={{ padding: '2rem' }}>
            <h1>Загрузка фото</h1>
            <input type="number" value={userId} onChange={e => setUserId(Number(e.target.value))} />
            <br /><br />
            <input type="file" onChange={e => {const f = e.target.files?.[0] ?? null; setFile(f);}} />
            <br /><br />
            <button onClick={handleUpload}>Загрузить</button>
            <pre>{result}</pre>
        </div>
    )
}

export default App;